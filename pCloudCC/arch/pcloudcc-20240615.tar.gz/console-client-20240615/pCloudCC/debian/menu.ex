?package(pcloudcc):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="pcloudcc" command="/usr/bin/pcloudcc"
