# Defaults for pcloudcc initscript
# sourced by /etc/init.d/pcloudcc
# installed at /etc/default/pcloudcc by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
