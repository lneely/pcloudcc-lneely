// MyOverlayIcon.cpp : Implementation of 

#include "stdafx.h"
#include "MyOverlayIcon.h"



